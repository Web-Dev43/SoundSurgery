# SoundSurgery

A free, browser-based audio editing prototype.

## Features
- Import multiple audio files and arrange clips on separate tracks
- Drag clips to move them between times and tracks
- Trim start/end, rename, duplicate, delete, mute
- Clip gain and stereo pan
- Live playback, master volume, bass boost and reverb
- Export the mixed project to WAV
- Record microphone audio where browser permissions and codec support allow

## Run locally
Open `index.html` in a modern browser. Microphone recording generally requires HTTPS or localhost.

## Publish free with Netlify Drop
1. Visit https://app.netlify.com/drop
2. Sign in if prompted
3. Drag the `soundsurgery` folder onto the page
4. Netlify gives you a public URL

You can also upload `index.html` to a GitHub repository and enable GitHub Pages.

## Limitations
This is a client-side prototype. Audio decoding depends on the browser. AI sound removal and stem separation are planned features, not implemented yet. Large files can use substantial memory. Keep backups of original audio.
